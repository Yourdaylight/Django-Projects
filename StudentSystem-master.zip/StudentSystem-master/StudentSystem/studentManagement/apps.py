from django.apps import AppConfig


class StudentmanagementConfig(AppConfig):
    name = 'studentManagement'
